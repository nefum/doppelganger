package xyz.regulad.pheidippides.administrate;

import android.app.Activity;

public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";
}
